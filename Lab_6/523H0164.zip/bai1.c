#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>


int checkPrime(int n,int i);

int main(){
    int i = 2;
    int n;
    printf("Enter a number to check if it is prime or not: ");
    scanf("%d",&n);

    if (checkPrime(n,i))
    {
        printf("%d is prime number",n);
    }
    else{
        printf("%d is not prime number",n);
    }
    
    return 0;
}


int checkPrime(int n,int i){
    if (n == i)
    {
        return 1;
    }
    if (n%i  == 0){
        return 0;
    }
    else {
        return checkPrime(n,i+1);
    }
}